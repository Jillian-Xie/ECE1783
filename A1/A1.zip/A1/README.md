# ECE1783 Assignment 1

To generate all the graphs, plots, Y-only reconstructed files and motion vectors, execute the MATLAB script ex3_report_script.m



To generate PSNR vs Bitcount， Execution times，Bitcount vs FrameIndex plots mentioned in part 2 of the report, execute the MATLAB script ex4_report_script.m